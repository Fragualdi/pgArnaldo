import java.util.Scanner;


public class ProvaMain {

	public static void main(String[] args) {		
		
		GestisciXml.leggiXml();
		

	}


}
